# Bibliothèque en ligne

Projet complet avec gestion des images.

## Installation

1. Placer dans `C:\laragon\www\bibliotheque\`
2. Créer la base avec `sql/schema.sql`
3. Insérer les données de test avec `sql/donnees.sql`
4. Accéder à `http://localhost/bibliotheque/public/`

## Compte test

- Email : jean@mail.fr
- Mot de passe : 12345678
