<?php
function validate_livre($data, $file)
{
    $errors = [];
    $titre = trim($data['titre'] ?? '');
    $auteur = trim($data['auteur'] ?? '');
    $description = trim($data['description'] ?? '');
    $maison = trim($data['maison_edition'] ?? '');
    $exemplaires = (int)($data['nombre_exemplaire'] ?? 1);

    if (mb_strlen($titre) < 2 || mb_strlen($titre) > 100) {
        $errors['titre'] = 'Le titre doit contenir entre 2 et 100 caractères.';
    }
    if (mb_strlen($auteur) < 2 || mb_strlen($auteur) > 100) {
        $errors['auteur'] = 'Le nom de l\'auteur doit contenir entre 2 et 100 caractères.';
    }
    if ($exemplaires < 0) {
        $errors['nombre_exemplaire'] = 'Le nombre d\'exemplaires ne peut pas être négatif.';
    }

    if ($file && ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $errors['image'] = 'Erreur lors de l\'upload de l\'image.';
        } else {
            $max = 2 * 1024 * 1024;
            if ($file['size'] > $max) {
                $errors['image'] = 'L\'image est trop volumineuse (max 2 Mo).';
            }
            $allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
            $mime = mime_content_type($file['tmp_name']);
            if (!in_array($mime, $allowed, true)) {
                $errors['image'] = 'Format d\'image non autorisé (JPEG, PNG, WEBP, GIF).';
            }
        }
    }

    $clean = [
        'titre' => $titre,
        'auteur' => $auteur,
        'description' => $description,
        'maison_edition' => $maison,
        'nombre_exemplaire' => $exemplaires
    ];
    return [$errors, $clean];
}

function validate_register($data)
{
    $errors = [];
    $nom = trim($data['nom'] ?? '');
    $prenom = trim($data['prenom'] ?? '');
    $email = trim($data['email'] ?? '');
    $password = $data['password'] ?? '';
    $password_confirm = $data['password_confirm'] ?? '';

    if (mb_strlen($nom) < 2 || mb_strlen($nom) > 100) {
        $errors['nom'] = 'Le nom doit contenir entre 2 et 100 caractères.';
    }
    if (mb_strlen($prenom) < 2 || mb_strlen($prenom) > 100) {
        $errors['prenom'] = 'Le prénom doit contenir entre 2 et 100 caractères.';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Adresse email invalide.';
    }
    if (mb_strlen($password) < 6) {
        $errors['password'] = 'Le mot de passe doit contenir au moins 6 caractères.';
    }
    if ($password !== $password_confirm) {
        $errors['password_confirm'] = 'Les mots de passe ne correspondent pas.';
    }
    $clean = [
        'nom' => $nom,
        'prenom' => $prenom,
        'email' => $email,
        'password' => $password
    ];
    return [$errors, $clean];
}
