<?php
function upload_image($file)
{
    // Extension d’origine (ex: png)
    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    // Nom unique : date + aléatoire
    $new = 'img_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    // Dossier de destination (côté serveur)
    $destDir = __DIR__ . '/../public/assets/uploads/';
    $destPath = $destDir . $new;
    if (!is_dir($destDir)) mkdir($destDir, 0777, true);
    // move_uploaded_file() déplace le fichier temporaire vers le dossier final
    if (!move_uploaded_file($file['tmp_name'], $destPath)) {
        return null;
    }
    // Chemin relatif depuis public/
    return 'assets/uploads/' . $new;
}

function delete_image($path)
{
    if ($path && file_exists(__DIR__ . '/../public/' . $path)) {
        unlink(__DIR__ . '/../public/' . $path);
    }
}
