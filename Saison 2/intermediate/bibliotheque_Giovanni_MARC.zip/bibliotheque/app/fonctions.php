<?php
function getAllLivres($pdo)
{
    $stmt = $pdo->query('SELECT * FROM livres ORDER BY titre');
    return $stmt->fetchAll();
}

function getLivreById($pdo, $id)
{
    $stmt = $pdo->prepare('SELECT * FROM livres WHERE id = :id');
    $stmt->execute([':id' => $id]);
    return $stmt->fetch();
}

function addLivre($pdo, $data)
{
    $stmt = $pdo->prepare('
        INSERT INTO livres (titre, auteur, description, maison_edition, nombre_exemplaire, image_path)
        VALUES (:titre, :auteur, :description, :maison, :exemplaires, :image)
    ');
    return $stmt->execute([
        ':titre' => $data['titre'],
        ':auteur' => $data['auteur'],
        ':description' => $data['description'],
        ':maison' => $data['maison_edition'],
        ':exemplaires' => $data['nombre_exemplaire'],
        ':image' => $data['image_path']
    ]);
}

function updateLivre($pdo, $id, $data)
{
    $stmt = $pdo->prepare('
        UPDATE livres SET
            titre = :titre,
            auteur = :auteur,
            description = :description,
            maison_edition = :maison,
            nombre_exemplaire = :exemplaires,
            image_path = :image
        WHERE id = :id
    ');
    $data['id'] = $id;
    return $stmt->execute([
        ':id' => $id,
        ':titre' => $data['titre'],
        ':auteur' => $data['auteur'],
        ':description' => $data['description'],
        ':maison' => $data['maison_edition'],
        ':exemplaires' => $data['nombre_exemplaire'],
        ':image' => $data['image_path']
    ]);
}

function deleteLivre($pdo, $id)
{
    $stmt = $pdo->prepare('DELETE FROM livres WHERE id = :id');
    return $stmt->execute([':id' => $id]);
}

function rechercherLivres($pdo, $mot)
{
    $stmt = $pdo->prepare('
        SELECT * FROM livres
        WHERE titre LIKE :mot1 OR auteur LIKE :mot2
        ORDER BY titre
    ');
    $mot = '%' . $mot . '%';
    $stmt->execute([':mot1' => $mot, ':mot2' => $mot]);
    return $stmt->fetchAll();
}

function getWishlist($pdo, $lecteur_id)
{
    $stmt = $pdo->prepare('
        SELECT l.*, ll.date_ajout FROM livres l
        JOIN liste_lecture ll ON ll.id_livre = l.id
        WHERE ll.id_lecteur = :id
        ORDER BY ll.date_ajout DESC
    ');
    $stmt->execute([':id' => $lecteur_id]);
    return $stmt->fetchAll();
}

function addToWishlist($pdo, $lecteur_id, $livre_id)
{
    $stmt = $pdo->prepare('
        INSERT IGNORE INTO liste_lecture (id_livre, id_lecteur)
        VALUES (:livre, :lecteur)
    ');
    return $stmt->execute([':livre' => $livre_id, ':lecteur' => $lecteur_id]);
}

function removeFromWishlist($pdo, $lecteur_id, $livre_id)
{
    $stmt = $pdo->prepare('
        DELETE FROM liste_lecture
        WHERE id_livre = :livre AND id_lecteur = :lecteur
    ');
    return $stmt->execute([':livre' => $livre_id, ':lecteur' => $lecteur_id]);
}
