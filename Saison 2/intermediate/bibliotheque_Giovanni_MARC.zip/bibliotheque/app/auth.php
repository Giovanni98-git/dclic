<?php
require_once __DIR__ . '/helpers.php';

function require_auth()
{
    start_session();
    if (!isset($_SESSION['lecteur_id'])) {
        set_flash('error', 'Veuillez vous connecter pour accéder à cette page.');
        header('Location: login.php');
        exit;
    }
}
