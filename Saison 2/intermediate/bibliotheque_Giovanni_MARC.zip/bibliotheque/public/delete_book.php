<?php
require_once __DIR__ . '/../app/helpers.php';
require_once __DIR__ . '/../app/fonctions.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/helpers_upload.php';
$pdo = require __DIR__ . '/../app/db.php';
start_session();

$id = (int)($_GET['id'] ?? 0);
$livre = getLivreById($pdo, $id);
if (!$livre) {
    set_flash('error', 'Livre introuvable.');
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($livre['image_path']) {
        delete_image($livre['image_path']);
    }
    deleteLivre($pdo, $id);
    set_flash('ok', 'Livre supprimé avec succès.');
    header('Location: index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supprimer un livre</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <div class="container">
        <header>
            <h1>🗑️ Supprimer un livre</h1>
            <nav>
                <a href="index.php">Accueil</a>
                <span>Bonjour <?= e($_SESSION['lecteur_prenom']) ?></span>
                <a href="logout.php">Déconnexion</a>
            </nav>
        </header>

        <div class="confirm-box">
            <p>Êtes-vous sûr de vouloir supprimer le livre <strong><?= e($livre['titre']) ?></strong> ?</p>
            <p class="warning">Cette action est irréversible.</p>
            <form method="post">
                <button type="submit" class="btn danger">Oui, supprimer</button>
                <a href="details.php?id=<?= e($id) ?>" class="btn secondary">Annuler</a>
            </form>
        </div>
    </div>
</body>

</html>