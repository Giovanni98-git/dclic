<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../app/helpers.php';
require_once __DIR__ . '/../app/fonctions.php';

try {
    $pdo = require __DIR__ . '/../app/db.php';
} catch (PDOException $e) {
    die('Erreur de connexion : ' . $e->getMessage());
}

start_session();

$q = trim($_GET['q'] ?? '');
$livres = [];

if ($q !== '') {
    try {
        $livres = rechercherLivres($pdo, $q);
    } catch (Exception $e) {
        die('Erreur lors de la recherche : ' . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Résultats de recherche</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <div class="container">
        <header>
            <h1>📚 Résultats pour « <?= e($q) ?> »</h1>
            <nav>
                <a href="index.php">Accueil</a>
                <a href="wishlist.php">Ma liste</a>
                <?php if (isset($_SESSION['lecteur_id'])): ?>
                    <span>Bonjour <?= e($_SESSION['lecteur_prenom']) ?></span>
                    <a href="logout.php">Déconnexion</a>
                <?php else: ?>
                    <a href="login.php">Connexion</a>
                <?php endif; ?>
            </nav>
        </header>

        <?php if (count($livres) > 0): ?>
            <div class="livre-grid">
                <?php foreach ($livres as $l): ?>
                    <div class="livre-card">
                        <?php if ($l['image_path']): ?>
                            <img src="<?= e($l['image_path']) ?>" alt="<?= e($l['titre']) ?>" class="livre-image">
                        <?php else: ?>
                            <div class="livre-image placeholder">📖</div>
                        <?php endif; ?>
                        <h3><?= e($l['titre']) ?></h3>
                        <p class="auteur"><?= e($l['auteur']) ?></p>
                        <p class="exemplaires">📖 <?= e($l['nombre_exemplaire']) ?> exemplaire(s)</p>
                        <a href="details.php?id=<?= e($l['id']) ?>" class="btn">Voir détails</a>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p>Aucun livre trouvé pour « <?= e($q) ?> ».</p>
        <?php endif; ?>
        <p><a href="index.php">Retour à l'accueil</a></p>
    </div>
</body>

</html>