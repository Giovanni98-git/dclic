<?php
require_once __DIR__ . '/../app/helpers.php';
$pdo = require __DIR__ . '/../app/db.php';
start_session();

$flash = get_flash();
$stmt = $pdo->query('SELECT * FROM livres ORDER BY id DESC LIMIT 10');
$livres = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bibliothèque en ligne</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <div class="container">
        <header>
            <h1>📚 Bibliothèque en ligne</h1>
            <nav>
                <a href="index.php">Accueil</a>
                <a href="wishlist.php">Ma liste</a>
                <?php if (isset($_SESSION['lecteur_id'])): ?>
                    <span>Bonjour <?= e($_SESSION['lecteur_prenom']) ?></span>
                    <a href="logout.php">Déconnexion</a>
                <?php else: ?>
                    <a href="login.php">Connexion</a>
                    <a href="register.php">Inscription</a>
                <?php endif; ?>
                <a href="add_book.php">+ Ajouter un livre</a>
            </nav>
        </header>

        <?php if ($flash): ?>
            <div class="alert <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
        <?php endif; ?>

        <section class="search-section">
            <h2>Rechercher un livre</h2>
            <form action="results.php" method="get" class="search-form">
                <input type="text" name="q" placeholder="Titre ou auteur..." required>
                <button type="submit">🔍 Rechercher</button>
            </form>
        </section>

        <section class="livres-recents">
            <h2>Derniers livres ajoutés</h2>
            <div class="livre-grid">
                <?php if (count($livres) > 0): ?>
                    <?php foreach ($livres as $l): ?>
                        <div class="livre-card">
                            <?php if ($l['image_path']): ?>
                                <img src="<?= e($l['image_path']) ?>" alt="<?= e($l['titre']) ?>" class="livre-image">
                            <?php else: ?>
                                <div class="livre-image placeholder">📖</div>
                            <?php endif; ?>
                            <h3><?= e($l['titre']) ?></h3>
                            <p class="auteur"><?= e($l['auteur']) ?></p>
                            <p class="exemplaires">📖 <?= e($l['nombre_exemplaire']) ?> exemplaire(s)</p>
                            <a href="details.php?id=<?= e($l['id']) ?>" class="btn">Voir détails</a>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>Aucun livre pour le moment.</p>
                <?php endif; ?>
            </div>
        </section>
    </div>
</body>

</html>