<?php
require_once __DIR__ . '/../app/helpers.php';
require_once __DIR__ . '/../app/validations.php';
require_once __DIR__ . '/../app/fonctions.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/helpers_upload.php';
$pdo = require __DIR__ . '/../app/db.php';
start_session();

$errors = [];
$values = [
    'titre' => '',
    'auteur' => '',
    'description' => '',
    'maison_edition' => '',
    'nombre_exemplaire' => 1,
    'image_path' => null
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    [$errors, $clean] = validate_livre($_POST, $_FILES['image'] ?? null);
    if (empty($errors)) {
        $imgPath = null;
        if (isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
            $imgPath = upload_image($_FILES['image']);
            if ($imgPath === null) {
                $errors['image'] = 'Erreur lors de l\'upload de l\'image.';
            }
        }
        if (empty($errors)) {
            $clean['image_path'] = $imgPath;
            $ok = addLivre($pdo, $clean);
            if ($ok) {
                set_flash('ok', 'Livre ajouté avec succès.');
                header('Location: index.php');
                exit;
            } else {
                $errors['general'] = 'Erreur lors de l\'ajout.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter un livre</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <script src="assets/js/app.js" defer></script>
</head>

<body>
    <div class="container">
        <header>
            <h1>➕ Ajouter un livre</h1>
            <nav>
                <a href="index.php">Accueil</a>
                <a href="wishlist.php">Ma liste</a>
                <span>Bonjour <?= e($_SESSION['lecteur_prenom']) ?></span>
                <a href="logout.php">Déconnexion</a>
            </nav>
        </header>

        <?php if (!empty($errors)): ?>
            <div class="alert error">Veuillez corriger les erreurs ci-dessous.</div>
        <?php endif; ?>

        <form method="post" enctype="multipart/form-data" class="form-livre">
            <div>
                <label for="titre">Titre *</label>
                <input type="text" id="titre" name="titre" value="<?= e($_POST['titre'] ?? '') ?>" required>
                <?php if (isset($errors['titre'])): ?><small class="error-msg"><?= e($errors['titre']) ?></small><?php endif; ?>
            </div>
            <div>
                <label for="auteur">Auteur *</label>
                <input type="text" id="auteur" name="auteur" value="<?= e($_POST['auteur'] ?? '') ?>" required>
                <?php if (isset($errors['auteur'])): ?><small class="error-msg"><?= e($errors['auteur']) ?></small><?php endif; ?>
            </div>
            <div>
                <label for="description">Description</label>
                <textarea id="description" name="description" rows="4"><?= e($_POST['description'] ?? '') ?></textarea>
            </div>
            <div>
                <label for="maison_edition">Maison d'édition</label>
                <input type="text" id="maison_edition" name="maison_edition" value="<?= e($_POST['maison_edition'] ?? '') ?>">
            </div>
            <div>
                <label for="nombre_exemplaire">Nombre d'exemplaires</label>
                <input type="number" id="nombre_exemplaire" name="nombre_exemplaire" value="<?= e($_POST['nombre_exemplaire'] ?? 1) ?>" min="0">
                <?php if (isset($errors['nombre_exemplaire'])): ?><small class="error-msg"><?= e($errors['nombre_exemplaire']) ?></small><?php endif; ?>
            </div>
            <div>
                <label for="image">Image (optionnelle)</label>
                <input type="file" id="image" name="image" accept="image/*">
                <?php if (isset($errors['image'])): ?><small class="error-msg"><?= e($errors['image']) ?></small><?php endif; ?>
            </div>
            <button type="submit" class="btn">Enregistrer</button>
            <a href="index.php" class="btn secondary">Annuler</a>
        </form>
    </div>
</body>

</html>