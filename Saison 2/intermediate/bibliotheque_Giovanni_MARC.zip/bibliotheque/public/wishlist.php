<?php
require_once __DIR__ . '/../app/helpers.php';
require_once __DIR__ . '/../app/fonctions.php';
require_once __DIR__ . '/../app/auth.php';
$pdo = require __DIR__ . '/../app/db.php';
start_session();

$lecteur_id = $_SESSION['lecteur_id'];
$wishlist = getWishlist($pdo, $lecteur_id);

if (isset($_GET['remove']) && is_numeric($_GET['remove'])) {
    $livre_id = (int)$_GET['remove'];
    removeFromWishlist($pdo, $lecteur_id, $livre_id);
    set_flash('ok', 'Livre retiré de votre liste.');
    header('Location: wishlist.php');
    exit;
}

$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ma liste de lecture</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <div class="container">
        <header>
            <h1>📋 Ma liste de lecture</h1>
            <nav>
                <a href="index.php">Accueil</a>
                <span>Bonjour <?= e($_SESSION['lecteur_prenom']) ?></span>
                <a href="logout.php">Déconnexion</a>
            </nav>
        </header>

        <?php if ($flash): ?>
            <div class="alert <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
        <?php endif; ?>

        <?php if (count($wishlist) > 0): ?>
            <div class="livre-grid">
                <?php foreach ($wishlist as $l): ?>
                    <div class="livre-card">
                        <?php if ($l['image_path']): ?>
                            <img src="<?= e($l['image_path']) ?>" alt="<?= e($l['titre']) ?>" class="livre-image">
                        <?php else: ?>
                            <div class="livre-image placeholder">📖</div>
                        <?php endif; ?>
                        <h3><?= e($l['titre']) ?></h3>
                        <p class="auteur"><?= e($l['auteur']) ?></p>
                        <p class="exemplaires">Ajouté le <?= date('d/m/Y', strtotime($l['date_ajout'])) ?></p>
                        <a href="details.php?id=<?= e($l['id']) ?>" class="btn">Voir</a>
                        <a href="wishlist.php?remove=<?= e($l['id']) ?>" class="btn danger" onclick="return confirm('Retirer ce livre de votre liste ?')">Retirer</a>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p>Vous n'avez pas encore de livres dans votre liste de lecture.</p>
        <?php endif; ?>
        <p><a href="index.php">Retour à l'accueil</a></p>
    </div>
</body>

</html>