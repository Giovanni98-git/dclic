document.addEventListener("DOMContentLoaded", function () {
  const form = document.querySelector(".form-livre");
  if (!form) return;

  form.addEventListener("submit", function (e) {
    const titre = form.querySelector('[name="titre"]');
    const auteur = form.querySelector('[name="auteur"]');
    let error = false;

    if (titre.value.trim().length < 2) {
      alert("Le titre doit contenir au moins 2 caractères.");
      error = true;
    }
    if (auteur.value.trim().length < 2) {
      alert("Le nom de l'auteur doit contenir au moins 2 caractères.");
      error = true;
    }
    if (error) {
      e.preventDefault();
    }
  });
});
