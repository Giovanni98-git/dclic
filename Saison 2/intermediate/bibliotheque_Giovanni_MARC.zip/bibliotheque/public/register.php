<?php
require_once __DIR__ . '/../app/helpers.php';
require_once __DIR__ . '/../app/validations.php';
$pdo = require __DIR__ . '/../app/db.php';
start_session();

// Rediriger si déjà connecté
if (isset($_SESSION['lecteur_id'])) {
    header('Location: index.php');
    exit;
}

$errors = [];
$values = ['nom' => '', 'prenom' => '', 'email' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    [$errors, $clean] = validate_register($_POST);
    if (empty($errors)) {
        // Vérifier si l'email existe déjà
        $stmt = $pdo->prepare('SELECT id FROM lecteurs WHERE email = :email');
        $stmt->execute([':email' => $clean['email']]);
        if ($stmt->fetch()) {
            $errors['email'] = 'Cette adresse email est déjà utilisée.';
        } else {
            // Hacher le mot de passe
            $hash = password_hash($clean['password'], PASSWORD_DEFAULT);
            $stmt = $pdo->prepare('
                INSERT INTO lecteurs (nom, prenom, email, password_hash)
                VALUES (:nom, :prenom, :email, :hash)
            ');
            $ok = $stmt->execute([
                ':nom' => $clean['nom'],
                ':prenom' => $clean['prenom'],
                ':email' => $clean['email'],
                ':hash' => $hash
            ]);
            if ($ok) {
                set_flash('ok', 'Inscription réussie. Vous pouvez maintenant vous connecter.');
                header('Location: login.php');
                exit;
            } else {
                $errors['general'] = 'Erreur lors de l\'inscription.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <div class="container">
        <header>
            <h1>📝 Inscription</h1>
            <nav>
                <a href="index.php">Accueil</a>
                <a href="login.php">Connexion</a>
            </nav>
        </header>

        <?php if (!empty($errors)): ?>
            <div class="alert error">Veuillez corriger les erreurs ci-dessous.</div>
        <?php endif; ?>

        <form method="post" class="form-auth">
            <div>
                <label for="nom">Nom *</label>
                <input type="text" id="nom" name="nom" value="<?= e($_POST['nom'] ?? '') ?>" required>
                <?php if (isset($errors['nom'])): ?><small class="error-msg"><?= e($errors['nom']) ?></small><?php endif; ?>
            </div>
            <div>
                <label for="prenom">Prénom *</label>
                <input type="text" id="prenom" name="prenom" value="<?= e($_POST['prenom'] ?? '') ?>" required>
                <?php if (isset($errors['prenom'])): ?><small class="error-msg"><?= e($errors['prenom']) ?></small><?php endif; ?>
            </div>
            <div>
                <label for="email">Email *</label>
                <input type="email" id="email" name="email" value="<?= e($_POST['email'] ?? '') ?>" required>
                <?php if (isset($errors['email'])): ?><small class="error-msg"><?= e($errors['email']) ?></small><?php endif; ?>
            </div>
            <div>
                <label for="password">Mot de passe * (min 6 caractères)</label>
                <input type="password" id="password" name="password" required>
                <?php if (isset($errors['password'])): ?><small class="error-msg"><?= e($errors['password']) ?></small><?php endif; ?>
            </div>
            <div>
                <label for="password_confirm">Confirmer le mot de passe *</label>
                <input type="password" id="password_confirm" name="password_confirm" required>
                <?php if (isset($errors['password_confirm'])): ?><small class="error-msg"><?= e($errors['password_confirm']) ?></small><?php endif; ?>
            </div>
            <button type="submit" class="btn">S'inscrire</button>
            <p>Déjà inscrit ? <a href="login.php">Se connecter</a></p>
        </form>
    </div>
</body>

</html>