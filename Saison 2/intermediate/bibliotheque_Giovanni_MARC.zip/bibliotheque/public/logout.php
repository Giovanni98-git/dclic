<?php
require_once __DIR__ . '/../app/helpers.php';
start_session();
$_SESSION = [];
session_destroy();
set_flash('ok', 'Vous êtes déconnecté.');
header('Location: index.php');
exit;
