<?php
require_once __DIR__ . '/../app/helpers.php';
require_once __DIR__ . '/../app/fonctions.php';
require_once __DIR__ . '/../app/auth.php';
$pdo = require __DIR__ . '/../app/db.php';
start_session();

$id = (int)($_GET['id'] ?? 0);
$livre = getLivreById($pdo, $id);
if (!$livre) {
    set_flash('error', 'Livre introuvable.');
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajouter_wishlist'])) {
    require_auth();
    $lecteur_id = $_SESSION['lecteur_id'];
    addToWishlist($pdo, $lecteur_id, $id);
    set_flash('ok', 'Livre ajouté à votre liste de lecture.');
    header('Location: details.php?id=' . $id);
    exit;
}

$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($livre['titre']) ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <div class="container">
        <header>
            <h1>📖 Détails du livre</h1>
            <nav>
                <a href="index.php">Accueil</a>
                <a href="wishlist.php">Ma liste</a>
                <?php if (isset($_SESSION['lecteur_id'])): ?>
                    <span>Bonjour <?= e($_SESSION['lecteur_prenom']) ?></span>
                    <a href="logout.php">Déconnexion</a>
                <?php else: ?>
                    <a href="login.php">Connexion</a>
                <?php endif; ?>
            </nav>
        </header>

        <?php if ($flash): ?>
            <div class="alert <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
        <?php endif; ?>

        <div class="detail-livre">
            <?php if ($livre['image_path']): ?>
                <img src="<?= e($livre['image_path']) ?>" alt="<?= e($livre['titre']) ?>" class="detail-image">
            <?php else: ?>
                <div class="detail-image placeholder">📖</div>
            <?php endif; ?>
            <h2><?= e($livre['titre']) ?></h2>
            <p><strong>Auteur :</strong> <?= e($livre['auteur']) ?></p>
            <p><strong>Maison d'édition :</strong> <?= e($livre['maison_edition'] ?: 'Non renseignée') ?></p>
            <p><strong>Nombre d'exemplaires :</strong> <?= e($livre['nombre_exemplaire']) ?></p>
            <p><strong>Description :</strong><br><?= nl2br(e($livre['description'] ?: 'Aucune description.')) ?></p>

            <form method="post" style="display:inline;">
                <button type="submit" name="ajouter_wishlist" class="btn">➕ Ajouter à ma liste de lecture</button>
            </form>
            <a href="edit_book.php?id=<?= e($livre['id']) ?>" class="btn secondary">✏️ Modifier</a>
            <a href="delete_book.php?id=<?= e($livre['id']) ?>" class="btn danger">🗑️ Supprimer</a>
            <a href="index.php" class="btn">Retour</a>
        </div>
    </div>
</body>

</html>