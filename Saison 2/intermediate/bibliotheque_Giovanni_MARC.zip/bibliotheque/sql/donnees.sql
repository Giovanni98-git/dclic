USE bibliotheque;

INSERT INTO
    `lecteurs` (`id`, `nom`, `prenom`, `email`, `password_hash`)
VALUES
    (
        1,
        'Jean',
        'Dupont',
        'jean@mail.fr',
        '$2y$10$LemZchXUgtnKdR/ToKQfguh56s6R81VdNxKxC/IOuNlQ/Zd2NZhwq'
    );

INSERT INTO
    livres (
        titre,
        auteur,
        description,
        maison_edition,
        nombre_exemplaire,
        image_path
    )
VALUES
    (
        'Le Petit Prince',
        'Antoine de Saint-Exupéry',
        'Un conte poétique et philosophique, intemporel.',
        'Gallimard',
        5,
        NULL
    ),
    (
        '1984',
        'George Orwell',
        'Une dystopie sur la surveillance totale et le totalitarisme.',
        'Seuil',
        3,
        NULL
    ),
    (
        'Dune',
        'Frank Herbert',
        'Un chef-d\'œuvre de science-fiction, premier tome de la saga.',
        'Robert Laffont',
        2,
        NULL
    ),
    (
        'L\'Étranger',
        'Albert Camus',
        'Un roman existentialiste sur l\'absurde.',
        'Gallimard',
        4,
        NULL
    ),
    (
        'Le Seigneur des Anneaux',
        'J.R.R. Tolkien',
        'Une épopée fantastique en trois tomes.',
        'Christian Bourgois',
        1,
        NULL
    );