CREATE DATABASE IF NOT EXISTS bibliotheque CHARACTER
SET
  utf8mb4 COLLATE utf8mb4_unicode_ci;

USE bibliotheque;

CREATE TABLE
  livres (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titre VARCHAR(100) NOT NULL,
    auteur VARCHAR(100) NOT NULL,
    description TEXT,
    maison_edition VARCHAR(100),
    nombre_exemplaire INT DEFAULT 1,
    image_path VARCHAR(255) NULL
  );

CREATE TABLE
  lecteurs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL
  );

CREATE TABLE
  liste_lecture (
    id_livre INT NOT NULL,
    id_lecteur INT NOT NULL,
    date_ajout TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id_livre, id_lecteur),
    FOREIGN KEY (id_livre) REFERENCES livres (id) ON DELETE CASCADE,
    FOREIGN KEY (id_lecteur) REFERENCES lecteurs (id) ON DELETE CASCADE
  );