PROJET : Gestion des formations

-------------------------------------
IMPORTATION DE LA BASE DE DONNEES
-------------------------------------

1. Ouvrir PhpMyAdmin.

2. Créer une base de données nommée :

gestion_formations

3. Importer le fichier :

schema.sql

4. Vérifier que les tables suivantes existent :

- apprenants
- formations
- sessions
- inscriptions

-------------------------------------
CONFIGURATION PHP
-------------------------------------

Serveur : localhost
Base : gestion_formations
Utilisateur : root
Mot de passe : vide

-------------------------------------
TEST DU SCRIPT
-------------------------------------

Placer le fichier :

connect_pdo.php

dans le dossier du serveur web.

Exemples :

http://localhost/connect_pdo.php

ou

http://127.0.0.1/connect_pdo.php

Si tout fonctionne, le message suivant apparaît :

Connexion réussie à la base de données.