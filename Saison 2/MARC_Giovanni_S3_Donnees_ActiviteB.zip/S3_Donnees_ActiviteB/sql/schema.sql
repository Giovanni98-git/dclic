-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 23, 2026 at 06:51 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gestion_formations`
--

-- --------------------------------------------------------

--
-- Table structure for table `apprenants`
--

CREATE TABLE `apprenants` (
  `id_apprenant` int(11) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `date_naissance` date DEFAULT NULL,
  `date_inscription` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `apprenants`
--

INSERT INTO `apprenants` (`id_apprenant`, `nom`, `prenom`, `email`, `telephone`, `date_naissance`, `date_inscription`) VALUES
(1, 'Dupont', 'Jean', 'jean@exemple.com', '0102030405', '1998-05-10', '2026-06-23 12:40:13'),
(2, 'Martin', 'Claire', 'claire@exemple.com', '0607080910', '1995-03-20', '2026-06-23 12:40:13'),
(3, 'Bernard', 'Luc', 'luc@exemple.com', NULL, '2000-08-15', '2026-06-23 12:40:13'),
(4, 'Petit', 'Emma', 'emma@exemple.com', '0505050505', '1999-12-01', '2026-06-23 12:40:13'),
(5, 'Moreau', 'Paul', 'paul@exemple.com', NULL, '1997-07-25', '2026-06-23 12:40:13');

-- --------------------------------------------------------

--
-- Table structure for table `formations`
--

CREATE TABLE `formations` (
  `id_formation` int(11) NOT NULL,
  `titre` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `niveau` enum('debutant','intermediaire','avance') NOT NULL,
  `duree_heures` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `formations`
--

INSERT INTO `formations` (`id_formation`, `titre`, `description`, `niveau`, `duree_heures`) VALUES
(1, 'PHP Débutant', 'Introduction à PHP', 'debutant', 30),
(2, 'MySQL Avancé', 'Optimisation et administration', 'avance', 40),
(3, 'Développement Web', 'HTML CSS JavaScript', 'intermediaire', 50);

-- --------------------------------------------------------

--
-- Table structure for table `inscriptions`
--

CREATE TABLE `inscriptions` (
  `id_inscription` int(11) NOT NULL,
  `id_apprenant` int(11) NOT NULL,
  `id_session` int(11) NOT NULL,
  `date_inscription` datetime NOT NULL,
  `statut` enum('en_attente','confirmee','annulee') NOT NULL,
  `note_finale` decimal(4,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inscriptions`
--

INSERT INTO `inscriptions` (`id_inscription`, `id_apprenant`, `id_session`, `date_inscription`, `statut`, `note_finale`) VALUES
(1, 1, 1, '2026-06-23 12:40:13', 'confirmee', 18.00),
(2, 2, 1, '2026-06-23 12:40:13', 'confirmee', 16.00),
(3, 3, 1, '2026-06-23 12:40:13', 'en_attente', NULL),
(4, 4, 2, '2026-06-23 12:40:13', 'confirmee', 17.00),
(5, 5, 2, '2026-06-23 12:40:13', 'annulee', NULL),
(6, 1, 3, '2026-06-23 12:40:13', 'confirmee', 19.00),
(7, 2, 3, '2026-06-23 12:40:13', 'en_attente', NULL),
(8, 3, 2, '2026-06-23 12:40:13', 'confirmee', 15.00);

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id_session` int(11) NOT NULL,
  `id_formation` int(11) NOT NULL,
  `date_debut` date NOT NULL,
  `date_fin` date NOT NULL,
  `lieu` enum('presentiel','en_ligne') NOT NULL,
  `nb_places` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id_session`, `id_formation`, `date_debut`, `date_fin`, `lieu`, `nb_places`) VALUES
(1, 1, '2026-04-01', '2026-04-30', 'presentiel', 20),
(2, 2, '2026-06-01', '2026-06-30', 'en_ligne', 15),
(3, 3, '2026-09-01', '2026-09-30', 'presentiel', 25);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `apprenants`
--
ALTER TABLE `apprenants`
  ADD PRIMARY KEY (`id_apprenant`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `formations`
--
ALTER TABLE `formations`
  ADD PRIMARY KEY (`id_formation`);

--
-- Indexes for table `inscriptions`
--
ALTER TABLE `inscriptions`
  ADD PRIMARY KEY (`id_inscription`),
  ADD UNIQUE KEY `id_apprenant` (`id_apprenant`,`id_session`),
  ADD KEY `id_session` (`id_session`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id_session`),
  ADD KEY `id_formation` (`id_formation`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `apprenants`
--
ALTER TABLE `apprenants`
  MODIFY `id_apprenant` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `formations`
--
ALTER TABLE `formations`
  MODIFY `id_formation` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `inscriptions`
--
ALTER TABLE `inscriptions`
  MODIFY `id_inscription` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `sessions`
--
ALTER TABLE `sessions`
  MODIFY `id_session` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `inscriptions`
--
ALTER TABLE `inscriptions`
  ADD CONSTRAINT `inscriptions_ibfk_1` FOREIGN KEY (`id_apprenant`) REFERENCES `apprenants` (`id_apprenant`) ON DELETE CASCADE,
  ADD CONSTRAINT `inscriptions_ibfk_2` FOREIGN KEY (`id_session`) REFERENCES `sessions` (`id_session`) ON DELETE CASCADE;

--
-- Constraints for table `sessions`
--
ALTER TABLE `sessions`
  ADD CONSTRAINT `sessions_ibfk_1` FOREIGN KEY (`id_formation`) REFERENCES `formations` (`id_formation`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
